MSL Feed Calculator Android Project v0.1

សំខាន់៖ នេះជាគម្រោងប្រភព Android Studio ដែលអាច Build ជា APK បាន មិនមែនជា APK ដែលបាន Compile រួចទេ។

អ្វីដែលមាន:
- Android WebView wrapper សម្រាប់កម្មវិធី MSL Feed Calculator
- កូដ Web App (Khmer/English)
- ការរក្សាទុកក្នុងឧបករណ៍តាម browser localStorage

អ្វីដែលមិនទាន់មាន:
- Cloud Sync មិនទាន់ភ្ជាប់។ ត្រូវបង្កើត Firebase/Cloud backend, authentication, database rules និងការសមកាលកម្ម។
- មិនទាន់បាន Build ឬសាកល្បងលើឧបករណ៍ Android ពិតប្រាកដទេ។

របៀប Build APK:
1. ដំឡើង Android Studio លើកុំព្យូទ័រ Windows/Mac/Linux។
2. Extract ZIP នេះ។
3. Android Studio > Open > ជ្រើស folder MSL_Feed_Calculator_Android_Project។
4. រង់ចាំ Gradle sync; ប្រសិនបើវាស្នើឱ្យដំឡើង Android SDK Platform 35 និង Build Tools សូមយល់ព្រម។
5. ជ្រើស Build > Build Bundle(s) / APK(s) > Build APK(s)។
6. បន្ទាប់ពី build ជោគជ័យ APK ស្ថិតនៅ app/build/outputs/apk/debug/app-debug.apk។
7. ផ្ទេរ APK ទៅ Android phone រួចបើកដំឡើង។ Android អាចស្នើឱ្យអនុញ្ញាត Install unknown apps សម្រាប់កម្មវិធី Files/Browser ដែលបើក APK។

ចំណាំសុវត្ថិភាព:
- កុំដំឡើង APK ពីប្រភពដែលមិនទុកចិត្ត។
- តម្លៃ CP និង ME ក្នុង prototype គឺជាតម្លៃប៉ាន់ស្មានដែលអាចកែបាន; ត្រូវផ្ទៀងផ្ទាត់ជាមួយ supplier/lab។
- ទិន្នន័យក្នុង localStorage អាចបាត់បង់បើលុប app data ឬ uninstall; ប្រើ Export backup ជាប្រចាំ។
